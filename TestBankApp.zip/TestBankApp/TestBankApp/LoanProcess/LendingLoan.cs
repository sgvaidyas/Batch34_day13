﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestBankApp.LoanProcess
{
    abstract class LendingLoan
    {
        public int type, custID, loan;
        public abstract float calculateLoan(int custID,int type, float wt,float fineness);
        public abstract float calculateLoan(int custID, int type, float wt, float fineness,int fees);
        public float LiquidateLoan(int custID,float amount,float liqAmount)
        {
            float pendingamount; 
            if(liqAmount<0)
            {
                pendingamount =amount+ liqAmount; 
            }
            else
            {
                pendingamount = amount;   
            }
            return pendingamount;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using TestBankApp.exceptions;

namespace TestBankApp.LoanProcess
{
    class OldCustomer:LendingLoan
    {
        public OldCustomer() : base() { }
        public override float calculateLoan(int custID, int type, float wt, float fineness)
        {
            float loan = 0;

            if (type != 0)
                throw new WrongType("Customer TYPE is wrong for CUSTID = " + custID);
            else if (fineness < 14 || fineness > 24)
                throw new WrongFineness("Fineness should be between 14-24");
            else
            {
                float val = 750 + (fineness - 14) * 50;
                val = (val * wt);
                loan = val;
            }

            return loan;
        }
        public override float calculateLoan(int custID, int type, float wt, float fineness, int fees)
        {
            float loan = 0;
            if (fees != 0)
                throw new WrongType("Wrong type of customer");
            else if (type != 0)
                throw new WrongType("Customer TYPE is wrong for CUSTID = " + custID);
            else if (fineness < 14 || fineness > 24)
                throw new WrongFineness("Fineness should be between 14-24");
            else
            {
                float val = 750 + (fineness - 14) * 50;
                val = (val * wt);
                loan = val;
            }
            return loan;

        }
    }
}

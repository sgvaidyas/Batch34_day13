﻿using System;
using System.Collections.Generic;
using TestBankApp.LoanProcess;

namespace TestBankApp
{
    class Program
    {
        static void Main(string[] args)
        {
            NewCustomer nc = new NewCustomer();
            float loanamt;
            try
            {

                loanamt = nc.calculateLoan(111, 1, 2, 17,300);
                Console.WriteLine("Loan amount = " + loanamt);
                Console.WriteLine("Pending amount = " + nc.LiquidateLoan(111, 1500, -670));
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            Console.WriteLine("OLD CUST\n_____");

            OldCustomer oc = new OldCustomer();
            try
            {

                loanamt = oc.calculateLoan(111, 0, 2, 17);
                Console.WriteLine("Loan amount = " + loanamt);
                Console.WriteLine("Pending amount = " + oc.LiquidateLoan(111, 1500, -670));
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

        }
    }
}

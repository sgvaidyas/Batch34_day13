﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestBankApp.exceptions
{
    class WrongType:Exception
    {
        public WrongType() : base() { }
        public WrongType(string message) : base(message) { }
        public WrongType(string message, System.Exception inner) : base(message, inner) { }
    }
}

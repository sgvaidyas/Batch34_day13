﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch34day13
{
    class qustions
    {
        static IEnumerable<int> Sequence(int start , int end)
        {
            for (int num = start + 1; num <= end; num++)
                if ( num%2==0||num > 10)
                    yield return num;

        }
        static void Main(string[] args)
        {
            var ob = Sequence(5, 9);
            Console.WriteLine("sum = "+ob.Sum());
            foreach(int x in ob)
                Console.WriteLine(x);

        }
    }
}
/*int i = 33;
            Console.WriteLine(i.GetType());

            float x = 77.3f;
            Console.WriteLine(x.GetType());

            long a = 778;
            Console.WriteLine(a.GetType());

            double b = 778;
            Console.WriteLine(b.GetType());


            char c='a';
            Console.WriteLine(c.GetType());

            decimal d = 88;
            Console.WriteLine(d.GetType());

    */
﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch34day13
{
    class Mobile
    {
        protected int ram;
        protected int rom;
        protected int cam;
        protected int grapics;
        protected float version;
        protected string processor;
        protected float price;



        public void getspecifications()
        {
            Console.WriteLine("Enter RAM");
            ram = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter ROM");
            rom = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter CAMERA");
            cam = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter GRAPHICS");
            grapics = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter VERSION");
            version = float.Parse(Console.ReadLine());
            Console.WriteLine("Enter PROCESSOR");
            processor = Console.ReadLine();
            Console.WriteLine("Enter PRICE");
            price = float.Parse(Console.ReadLine());
        }

        public void display()
        {
            Console.WriteLine("RAM is " + ram);
            Console.WriteLine("ROM is " + rom);
            Console.WriteLine("CAMERA is " + cam);
            Console.WriteLine("GRAPICS is " + grapics);
            Console.WriteLine("VERSION is " + version);
            Console.WriteLine("PROCESSOR is " + processor);
            Console.WriteLine("PRICE is " + price);
        }
        public void writefile()
        {
            string filename = @"D:\myfiles\Mobiledoc.txt";
            using (BinaryWriter bw = new BinaryWriter(File.Open(filename, FileMode.Create)))
            {
                bw.Write(ram);
                bw.Write(rom);
                bw.Write(cam);
                bw.Write(grapics);
                bw.Write(version);
                bw.Write(processor);
                bw.Write(price);
            }
            Console.WriteLine("DATA SUCCESSFULLY INSERTED");
        }
        public void readMob()
        {
            string filename = @"D:\myfiles\Mobiledoc.txt";
            using (BinaryReader br = new BinaryReader(File.Open(filename, FileMode.Open)))
            {
                Console.WriteLine("RAM is " + br.ReadInt32());
                Console.WriteLine("ROM is " + br.ReadInt32());
                Console.WriteLine("CAMERA is " + br.ReadInt32());
                Console.WriteLine("GRAPICS is " + br.ReadInt32());
                Console.WriteLine("VERSION is " + br.ReadSingle());
                Console.WriteLine("PROCESSOR is " + br.ReadString());
                Console.WriteLine("PRICE is " + br.ReadSingle());
            }
        }
    }
    class ImplementMobile
    {
        static void Main(string[] args)
        {
            Mobile ob = new Mobile();
            ob.getspecifications();
            //ob.display();
            ob.writefile();
            Console.WriteLine("from file");
            ob.readMob();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Threading.Tasks;

namespace Batch34day13
{
    class _2TextReader_writer
    {
        static void Main(string[] args)
        {
            string filename = @"D:\myfiles\textwrite.txt";
            using (TextWriter tw = File.CreateText(filename))
            {
                tw.WriteLine("this is first line");
                tw.WriteLine("this is second");
            }
            Console.WriteLine("file is updated");
            Console.WriteLine("\n\n FILECONTENT=\n_____________________________");
            using (TextReader tr = File.OpenText(filename))
            {
                Console.WriteLine(tr.ReadToEnd());

            }
        }
    }
}
